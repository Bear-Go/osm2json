把 map.osm 放在当前目录下 文件名必须为 map.osm

然后在命令行执行 bash convert 即可得到 map.net.xml 和 map_cityflow.json